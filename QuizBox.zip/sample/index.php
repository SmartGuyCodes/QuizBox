<?php 
exit('permission denied');
?>