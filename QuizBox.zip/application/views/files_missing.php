 <div class="container">

  <div class="row">
    
<div class="col-md-10">
<br> 
  	
 <h3><?php echo $title;?></h3>
   
 <div class="alert alert-danger"><?php echo $this->lang->line('files_missing2');?></div>
 
 
 
 
 

</div> 

</div> 
 


</div> 
