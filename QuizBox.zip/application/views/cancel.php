 <div class="container">

  <div class="row">
    
<div class="col-md-8">
<br> 
 <div class="login-panel panel panel-default">
		<div class="panel-body"> 
	  	<img src="<?php echo base_url('images/logo.png');?>">
	
 <h3><?php echo $title;?></h3>
   
 <br>
 <a href="<?php echo site_url('login');?>"><?php echo $this->lang->line('login');?></a> 
 
 
 
 
 
 
 
</div> 

</div> 

</div> 

</div> 
 


</div> 