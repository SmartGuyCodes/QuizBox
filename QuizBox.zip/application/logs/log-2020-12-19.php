<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-19 18:22:35 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-12-19 18:29:17 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2020-12-19 18:36:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-12-19 18:36:58 --> Could not find the language line "hello"
ERROR - 2020-12-19 18:36:58 --> Could not find the language line "user_id"
