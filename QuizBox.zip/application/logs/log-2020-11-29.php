<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-29 16:15:47 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-29 17:24:00 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-29 22:13:54 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-29 23:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-29 23:20:28 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2020-11-29 23:21:18 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
