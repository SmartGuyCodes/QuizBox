<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-04 23:02:31 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
