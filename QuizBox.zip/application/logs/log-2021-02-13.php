<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-13 05:58:29 --> Could not find the language line "quizbox"
ERROR - 2021-02-13 10:41:07 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
