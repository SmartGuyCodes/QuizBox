<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 22:51:17 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
