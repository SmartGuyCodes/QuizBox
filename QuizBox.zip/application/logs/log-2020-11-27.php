<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-27 15:20:18 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-27 15:21:07 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-27 15:24:43 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2020-11-27 15:25:28 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 193
ERROR - 2020-11-27 15:40:12 --> Could not find the language line "hello"
ERROR - 2020-11-27 15:40:12 --> Could not find the language line "user_id"
ERROR - 2020-11-27 15:42:12 --> Could not find the language line "appointment_timing"
ERROR - 2020-11-27 16:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 110
ERROR - 2020-11-27 16:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 199
ERROR - 2020-11-27 16:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 110
ERROR - 2020-11-27 16:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 199
ERROR - 2020-11-27 16:32:25 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-27 16:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
