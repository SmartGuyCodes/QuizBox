<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-28 11:29:27 --> Could not find the language line "quizbox"
ERROR - 2021-02-28 23:47:56 --> Could not find the language line "quizbox"
