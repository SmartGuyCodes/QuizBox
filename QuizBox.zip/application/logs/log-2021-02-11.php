<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 09:47:24 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 10:57:22 --> Severity: error --> Exception: Call to undefined method CI_Loader::studymaterial_model() /home1/trucommc/quizbox/application/controllers/Landing.php 10
ERROR - 2021-02-11 10:57:25 --> Severity: error --> Exception: Call to undefined method CI_Loader::studymaterial_model() /home1/trucommc/quizbox/application/controllers/Landing.php 10
ERROR - 2021-02-11 10:57:32 --> Severity: error --> Exception: Call to undefined method CI_Loader::studymaterial_model() /home1/trucommc/quizbox/application/controllers/Landing.php 10
ERROR - 2021-02-11 11:25:07 --> Could not find the language line "QuizBox"
ERROR - 2021-02-11 11:25:25 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:25:30 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:33:40 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:36:03 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:36:07 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:37:38 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:39:24 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:40:25 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:41:06 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:42:26 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:43:40 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:47:06 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:47:16 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:47:43 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:48:56 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:49:25 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:50:34 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:50:49 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:52:16 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:53:45 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:53:48 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:58:05 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 11:59:47 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:06:41 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:17:13 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:18:10 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:21:30 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 12:23:41 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:24:27 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:24:41 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 12:25:06 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 12:25:08 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:26:43 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:26:45 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:26:50 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 12:30:31 --> Severity: error --> Exception: Call to a member function getSingleMaterial() on null /home1/trucommc/quizbox/application/controllers/Shule.php 49
ERROR - 2021-02-11 13:29:16 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 13:30:01 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 13:36:25 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 13:41:29 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2021-02-11 13:43:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 421
ERROR - 2021-02-11 13:44:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2021-02-11 13:45:18 --> Could not find the language line "hello"
ERROR - 2021-02-11 13:45:18 --> Could not find the language line "user_id"
ERROR - 2021-02-11 13:45:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home1/trucommc/quizbox/application/views/view_result.php 356
ERROR - 2021-02-11 13:55:53 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-11 14:22:41 --> Could not find the language line "quizbox"
ERROR - 2021-02-11 14:24:29 --> Could not find the language line "quizbox"
