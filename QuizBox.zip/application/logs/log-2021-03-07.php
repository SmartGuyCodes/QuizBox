<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-07 02:07:07 --> Could not find the language line "quizbox"
ERROR - 2021-03-07 19:24:55 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'trucommc_liz'@'localhost' (using password: YES) /home1/trucommc/quizbox/application/config/config.php 516
