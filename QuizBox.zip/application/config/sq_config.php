<?php 
		$sq_base_url='https://quizbox.trucomm.co.ke/';
		$sq_hostname='localhost';
		$sq_dbname='trucommc_quizbox';
		$sq_dbusername='trucommc_liz';
		$sq_dbpassword='))r_IvxnGM+E';
		?>