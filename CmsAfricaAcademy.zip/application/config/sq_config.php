<?php 
	$sq_base_url='http://dev.cmsafrica.academy/';
	$sq_hostname='localhost';
	$sq_dbname='cmsafrica_academy';
	$sq_dbusername='phpmyadmin';
	$sq_dbpassword='FuckYou!';
?>