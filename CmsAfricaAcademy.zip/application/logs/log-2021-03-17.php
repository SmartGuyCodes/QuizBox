<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-17 18:27:31 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'trucommc_liz'@'localhost' (using password: YES) /home1/trucommc/quizbox/application/config/config.php 516
