<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 06:08:03 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user 'trucommc_liz'@'localhost' (using password: YES) /home1/trucommc/quizbox/application/config/config.php 516
ERROR - 2021-03-24 06:26:25 --> Could not find the language line "quizbox"
ERROR - 2021-03-24 06:37:10 --> Could not find the language line "quizbox"
ERROR - 2021-03-24 06:37:25 --> Could not find the language line "quizbox"
