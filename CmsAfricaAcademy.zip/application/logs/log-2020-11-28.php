<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-28 01:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-28 01:50:46 --> Could not find the language line "hello"
ERROR - 2020-11-28 01:50:46 --> Could not find the language line "user_id"
ERROR - 2020-11-28 01:50:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2020-11-28 01:50:47 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home1/trucommc/quizbox/application/models/Result_model.php 161
ERROR - 2020-11-28 02:14:37 --> Could not find the language line "hello"
ERROR - 2020-11-28 02:14:37 --> Could not find the language line "user_id"
ERROR - 2020-11-28 02:14:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2020-11-28 02:14:38 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home1/trucommc/quizbox/application/models/Result_model.php 161
ERROR - 2020-11-28 02:19:08 --> Could not find the language line "hello"
ERROR - 2020-11-28 02:19:08 --> Could not find the language line "user_id"
ERROR - 2020-11-28 02:19:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2020-11-28 02:19:10 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /home1/trucommc/quizbox/application/models/Result_model.php 161
