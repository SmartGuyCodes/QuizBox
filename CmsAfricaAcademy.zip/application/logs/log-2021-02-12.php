<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-12 12:02:38 --> Could not find the language line "quizbox"
ERROR - 2021-02-12 13:11:56 --> Could not find the language line "quizbox"
ERROR - 2021-02-12 18:25:32 --> Could not find the language line "quizbox"
