<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-25 13:43:02 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
