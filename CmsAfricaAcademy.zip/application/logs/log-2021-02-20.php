<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-20 13:50:08 --> Could not find the language line "quizbox"
ERROR - 2021-02-20 15:04:01 --> Could not find the language line "quizbox"
ERROR - 2021-02-20 16:42:00 --> Could not find the language line "quizbox"
ERROR - 2021-02-20 18:05:35 --> Could not find the language line "quizbox"
ERROR - 2021-02-20 22:31:02 --> Could not find the language line "quizbox"
