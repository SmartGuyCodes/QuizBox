<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-20 22:10:05 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /home1/trucommc/quizbox/application/config/config.php 515
ERROR - 2020-11-20 22:10:05 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) /home1/trucommc/quizbox/application/config/config.php 515
ERROR - 2020-11-20 22:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:27:35 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:27:35 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 22:27:35 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:27:35 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 22:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:31:39 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:31:39 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 22:31:39 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:31:39 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 22:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:34:31 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:34:31 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 22:34:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/config/config.php 524
ERROR - 2020-11-20 22:34:32 --> Query error: Table 'trucommc_quizbox.savsoft_quiz' doesn't exist - Invalid query: SELECT *
FROM `savsoft_quiz`
ORDER BY `quid` DESC
 LIMIT 5
ERROR - 2020-11-20 22:34:32 --> Severity: error --> Exception: Call to a member function result_array() on boolean /home1/trucommc/quizbox/application/models/Quiz_model.php 111
ERROR - 2020-11-20 23:04:04 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-20 23:40:55 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-20 23:43:42 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-20 23:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 421
