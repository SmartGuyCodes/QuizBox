<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 01:23:05 --> Could not find the language line "quizbox"
ERROR - 2021-02-15 04:40:07 --> Could not find the language line "quizbox"
ERROR - 2021-02-15 15:04:03 --> Could not find the language line "quizbox"
ERROR - 2021-02-15 22:12:31 --> Could not find the language line "quizbox"
