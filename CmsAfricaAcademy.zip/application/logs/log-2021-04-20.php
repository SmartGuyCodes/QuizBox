<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-20 05:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 06:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 08:52:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 09:11:54 --> Query error: Table 'cmsafrica_academy.savsoftquiz_setting' doesn't exist - Invalid query:  select * from savsoftquiz_setting where setting_name='App_Name' || setting_name='App_title' order by setting_id asc 
ERROR - 2021-04-20 09:11:54 --> Severity: error --> Exception: Call to a member function result_Array() on bool /var/www/html/cmsafrica.academy/application/views/login.php 53
ERROR - 2021-04-20 09:12:00 --> Query error: Table 'cmsafrica_academy.savsoftquiz_setting' doesn't exist - Invalid query:  select * from savsoftquiz_setting where setting_name='App_Name' || setting_name='App_title' order by setting_id asc 
ERROR - 2021-04-20 09:12:00 --> Severity: error --> Exception: Call to a member function result_Array() on bool /var/www/html/cmsafrica.academy/application/views/login.php 53
ERROR - 2021-04-20 09:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 09:35:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:21:51 --> Query error: Table 'cmsafrica_academy.savsoft_group' doesn't exist - Invalid query: select * from savsoft_group where gid in (1) 
ERROR - 2021-04-20 10:21:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/html/cmsafrica.academy/application/controllers/Login.php 158
ERROR - 2021-04-20 10:22:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:22:53 --> Query error: Table 'cmsafrica_academy.savsoftquiz_setting' doesn't exist - Invalid query:  select * from savsoftquiz_setting where setting_name='App_Name' || setting_name='App_title' order by setting_id asc 
ERROR - 2021-04-20 10:22:53 --> Severity: error --> Exception: Call to a member function result_Array() on bool /var/www/html/cmsafrica.academy/application/views/header.php 70
ERROR - 2021-04-20 10:27:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:27:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-20 10:34:28 --> Query error: Table 'cmsafrica_academy.savsoftquiz_setting' doesn't exist - Invalid query:  select * from savsoftquiz_setting where setting_name='App_Name' || setting_name='App_title' order by setting_id asc 
ERROR - 2021-04-20 10:34:28 --> Severity: error --> Exception: Call to a member function result_Array() on bool /var/www/html/cmsafrica.academy/application/views/header.php 70
ERROR - 2021-04-20 10:36:22 --> Query error: Table 'cmsafrica_academy.savsoft_users' doesn't exist - Invalid query: select * from appointment_request 
	join savsoft_users on savsoft_users.uid=appointment_request.request_by 
	 where appointment_request.to_id='1' and appointment_request.appointment_status='Pending' 
ERROR - 2021-04-20 10:36:22 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/html/cmsafrica.academy/application/views/header.php 355
ERROR - 2021-04-20 10:37:30 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 10:37:30 --> Query error: Table 'cmsafrica_academy.savsoft_add' doesn't exist - Invalid query: SELECT *
FROM `savsoft_add`
WHERE `add_status` = 'Active'
AND `position` = 'Bottom'
ERROR - 2021-04-20 10:37:30 --> Severity: error --> Exception: Call to a member function num_rows() on bool /var/www/html/cmsafrica.academy/application/views/footer.php 19
ERROR - 2021-04-20 10:38:31 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 10:40:14 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 10:42:53 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 10:42:56 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 10:49:42 --> Query error: Table 'cmsafrica_academy.savsoft_notification' doesn't exist - Invalid query: update savsoft_notification set viewed='1' where uid='1' 
ERROR - 2021-04-20 10:50:11 --> Query error: Table 'cmsafrica_academy.savsoft_notification' doesn't exist - Invalid query: update savsoft_notification set viewed='1' where uid='1' 
ERROR - 2021-04-20 10:52:30 --> Query error: Table 'cmsafrica_academy.savsoft_users' doesn't exist - Invalid query:  update savsoft_users set gid='1' where gid='3' 
ERROR - 2021-04-20 10:52:37 --> Query error: Table 'cmsafrica_academy.savsoft_users' doesn't exist - Invalid query:  update savsoft_users set gid='1' where gid='4' 
ERROR - 2021-04-20 10:53:02 --> Query error: Table 'cmsafrica_academy.savsoft_qbank' doesn't exist - Invalid query:  update savsoft_qbank set cid='1' where cid='2' 
ERROR - 2021-04-20 10:53:08 --> Query error: Table 'cmsafrica_academy.savsoft_qbank' doesn't exist - Invalid query:  update savsoft_qbank set cid='' where cid='1' 
ERROR - 2021-04-20 10:56:27 --> Query error: Table 'cmsafrica_academy.savsoft_qbank' doesn't exist - Invalid query:  update savsoft_qbank set cid='9' where cid='10' 
ERROR - 2021-04-20 10:58:05 --> Query error: Table 'cmsafrica_academy.savsoft_qbank' doesn't exist - Invalid query:  update savsoft_qbank set lid='2' where lid='1' 
ERROR - 2021-04-20 10:58:11 --> Query error: Table 'cmsafrica_academy.savsoft_qbank' doesn't exist - Invalid query:  update savsoft_qbank set lid='' where lid='2' 
ERROR - 2021-04-20 14:12:09 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:16:30 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:17:33 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:19:23 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/models/User_model.php 620
ERROR - 2021-04-20 14:20:22 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:25:38 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:27:09 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:27:31 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:27:40 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:29:42 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:30:36 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 14:31:09 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 17:00:52 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 17:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/models/User_model.php 620
ERROR - 2021-04-20 17:02:17 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 17:02:34 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 17:03:52 --> Query error: Table 'cmsafrica_academy.savsoft_users' doesn't exist - Invalid query: SELECT *
FROM `savsoft_users`
WHERE `email` = 'teacher@cmsafrica.academy'
 LIMIT 1
ERROR - 2021-04-20 17:03:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool /var/www/html/cmsafrica.academy/system/libraries/Form_validation.php 1122
ERROR - 2021-04-20 17:11:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/models/User_model.php 416
ERROR - 2021-04-20 17:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/models/User_model.php 416
ERROR - 2021-04-20 17:14:06 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
ERROR - 2021-04-20 17:15:48 --> Severity: Warning --> Division by zero /var/www/html/cmsafrica.academy/application/views/dashboard.php 237
