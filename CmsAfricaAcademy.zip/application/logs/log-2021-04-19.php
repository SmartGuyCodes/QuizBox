<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-19 00:00:55 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:01:02 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-19 00:53:04 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-19 00:53:35 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-19 00:54:18 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:54:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
ERROR - 2021-04-19 00:54:44 --> Could not find the language line "quizbox"
ERROR - 2021-04-19 00:55:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/cmsafrica.academy/application/config/config.php 525
