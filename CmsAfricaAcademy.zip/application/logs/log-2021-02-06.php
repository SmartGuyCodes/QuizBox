<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-06 14:36:11 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-06 15:19:11 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2021-02-06 15:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 421
ERROR - 2021-02-06 15:22:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2021-02-06 15:23:56 --> Could not find the language line "hello"
ERROR - 2021-02-06 15:23:56 --> Could not find the language line "user_id"
ERROR - 2021-02-06 15:23:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home1/trucommc/quizbox/application/views/view_result.php 356
ERROR - 2021-02-06 15:23:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2021-02-06 15:23:56 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home1/trucommc/quizbox/application/models/Result_model.php 161
ERROR - 2021-02-06 15:23:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2021-02-06 15:23:56 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home1/trucommc/quizbox/application/models/Result_model.php 161
ERROR - 2021-02-06 17:45:34 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2021-02-06 17:46:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
ERROR - 2021-02-06 17:47:52 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
