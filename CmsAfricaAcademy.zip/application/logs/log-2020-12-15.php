<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 01:23:45 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-12-15 01:24:30 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
