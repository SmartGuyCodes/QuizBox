<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 19:31:15 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
