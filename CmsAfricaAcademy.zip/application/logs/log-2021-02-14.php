<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-14 16:46:06 --> Could not find the language line "quizbox"
ERROR - 2021-02-14 17:07:59 --> Could not find the language line "quizbox"
ERROR - 2021-02-14 18:42:05 --> Could not find the language line "quizbox"
ERROR - 2021-02-14 20:56:26 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
