<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-21 00:07:57 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 00:34:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
ERROR - 2020-11-21 00:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/Quiz_model.php 878
ERROR - 2020-11-21 00:39:42 --> Could not find the language line "hello"
ERROR - 2020-11-21 00:39:42 --> Could not find the language line "user_id"
ERROR - 2020-11-21 00:41:49 --> Could not find the language line "appointment_timing"
ERROR - 2020-11-21 00:45:43 --> Could not find the language line "hello"
ERROR - 2020-11-21 00:45:43 --> Could not find the language line "user_id"
ERROR - 2020-11-21 00:48:17 --> Could not find the language line "hello"
ERROR - 2020-11-21 00:48:17 --> Could not find the language line "user_id"
ERROR - 2020-11-21 00:52:22 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 00:57:31 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 00:57:56 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 10:19:19 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 10:38:30 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 10:43:53 --> Severity: Warning --> Missing argument 1 for Quiz::quiz_detail(), called in /home1/trucommc/quizbox/system/core/CodeIgniter.php on line 532 and defined /home1/trucommc/quizbox/application/controllers/Quiz.php 449
ERROR - 2020-11-21 16:57:00 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-21 17:17:02 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
