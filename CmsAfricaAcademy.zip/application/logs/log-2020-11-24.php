<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-24 13:14:27 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 13:14:59 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 13:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 421
ERROR - 2020-11-24 13:23:27 --> Severity: Warning --> implode(): Invalid arguments passed /home1/trucommc/quizbox/application/models/Quiz_model.php 155
ERROR - 2020-11-24 13:33:10 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 14:01:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
ERROR - 2020-11-24 14:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
ERROR - 2020-11-24 14:06:51 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 14:21:18 --> Could not find the language line "hello"
ERROR - 2020-11-24 14:21:18 --> Could not find the language line "user_id"
ERROR - 2020-11-24 14:22:01 --> Could not find the language line "appointment_timing"
ERROR - 2020-11-24 14:22:15 --> Could not find the language line "hello"
ERROR - 2020-11-24 14:22:15 --> Could not find the language line "user_id"
ERROR - 2020-11-24 14:25:35 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 14:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/models/User_model.php 620
ERROR - 2020-11-24 14:54:59 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 14:56:37 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 14:57:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 110
ERROR - 2020-11-24 14:57:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home1/trucommc/quizbox/application/views/profile.php 199
ERROR - 2020-11-24 21:06:29 --> Severity: Warning --> Division by zero /home1/trucommc/quizbox/application/views/dashboard.php 237
ERROR - 2020-11-24 21:07:06 --> Could not find the language line "hello"
ERROR - 2020-11-24 21:07:06 --> Could not find the language line "user_id"
